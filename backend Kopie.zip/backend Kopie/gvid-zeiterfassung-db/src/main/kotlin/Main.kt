fun main() {
    println(greeting("gvid-zeiterfassung-db"))
}

fun greeting(name: String) =
        "Hello, $name"