import kotlin.test.Test
import kotlin.test.assertEquals

class GreetingTest {
    @Test
    fun testGreeting() {
        assertEquals(greeting("World"), "Hello, World")
    }
}